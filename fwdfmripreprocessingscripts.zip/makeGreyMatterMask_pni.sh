
3dcopy /Volumes/cohen/mci/freesurfer/subjects/$1/SUMA/$1_SurfVol+orig .

3dSurf2Vol -spec /Volumes/cohen/mci/freesurfer/subjects/$1/SUMA/$1_lh.spec -surf_A smoothwm -surf_B pial -sv $1_SurfVol+orig -grid_parent $1_SurfVol+orig -map_func mask2 -f_steps 50 -prefix lh_gm
3dSurf2Vol -spec /Volumes/cohen/mci/freesurfer/subjects/$1/SUMA/$1_rh.spec -surf_A smoothwm -surf_B pial -sv $1_SurfVol+orig -grid_parent $1_SurfVol+orig -map_func mask2 -f_steps 50 -prefix rh_gm
3dcalc -a lh_gm+orig -b rh_gm+orig -expr 'or(equals(a,1),equals(b,1))' -prefix gm

3dSkullStrip -input $1_SurfVol+orig -prefix $1_SurfVol_stripped
\@Align_Centers -cm -base anat_stripped+orig -dset $1_SurfVol_stripped+orig -child gm+orig $1_SurfVol+orig

3dmerge -1blur_fwhm 4.0 -prefix gm_shft_smooth gm_shft+orig
3dresample -master Processed/clean+orig -prefix gm_shft_smooth_resamp+orig -input gm_shft_smooth+orig

mkdir roi
3dmaskdump -mask gm_shft_smooth_resamp+orig Processed/clean6+orig > roi/graymatter.txt
