
afni_proc.py -script AFNIprocess \
    -out_dir Processed \
    -scr_overwrite \
    -dsets RawData/run1.nii.gz RawData/run2.nii.gz RawData/run3.nii.gz RawData/run4.nii.gz RawData/run5.nii.gz RawData/run6.nii.gz \
    -tcat_remove_first_trs 6 \
    -mask_dilate 0 \
    -copy_anat anat_stripped+orig \
    -anat_has_skull no \
    -volreg_align_e2a \
    -volreg_warp_dxyz 2.0 \
    -blocks tshift align volreg mask scale \
    -execute
