recon-all -i anat.nii.gz -autorecon1 -notal-check -subjid $1;
recon-all -autorecon2 -subjid $1;
recon-all -autorecon3 -subjid $1;
