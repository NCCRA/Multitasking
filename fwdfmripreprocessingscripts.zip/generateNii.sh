
mkdir ./RawData/"$1"-"$2"
cp ./RawData/dcm/"$2"-* ./RawData/"$1"-"$2"
gzip -d ./RawData/"$1"-"$2"/*
dcm2niix -f run"$1" -o ./RawData/ -z y ./RawData/"$1"-"$2"/
