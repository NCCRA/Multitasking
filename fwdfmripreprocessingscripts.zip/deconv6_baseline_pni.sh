#!/bin/bash

3dDeconvolve -input Processed/pb03.SUBJ.r??.scale+orig.HEAD                   \
	-polort 6 \
	-mask Processed/full_mask.SUBJ+orig \
    -nfirst 0                                              \
    -num_stimts 6                                                   \
    -stim_file 1 Processed/dfile_rall.1D'[0]' -stim_base 1 -stim_label 1 roll  \
    -stim_file 2 Processed/dfile_rall.1D'[1]' -stim_base 2 -stim_label 2 pitch \
    -stim_file 3 Processed/dfile_rall.1D'[2]' -stim_base 3 -stim_label 3 yaw   \
    -stim_file 4 Processed/dfile_rall.1D'[3]' -stim_base 4 -stim_label 4 dS \
    -stim_file 5 Processed/dfile_rall.1D'[4]' -stim_base 5 -stim_label 5 dL \
    -stim_file 6 Processed/dfile_rall.1D'[5]' -stim_base 6 -stim_label 6 dP \
    -errts Processed/clean6 \
    -nobucket \
	-jobs 3
	
