function [ samples, position ] = extractTimecourses_RawFirstZ_LineLoad_10May17( subjId, area, figuresOn, hemoLag, outputFile )

if nargin < 2, error( 'Must specify subject and ROI.' ); end
if nargin < 3, figuresOn = 1; end
if nargin < 4, hemoLag = 4; end % 3 TRs = 4.5 secs
if nargin < 5, outputFile = [ './' subjId '/' subjId '_' area '.mat' ]; end

fprintf( '\nLoading Data ' );

load( [ './' subjId '/timings.mat' ] ); % timings.first
[ numRuns, numCategories, ~ ] = size( timings.first );
load( [ '../logs/semFmri' subjId '.mat' ] ); % params

fid = fopen( [ './' subjId '/' area '.txt' ] );

xpLength = 3087;
tline = fgetl( fid ); i = 0; q = 0;
while ischar( tline )
    i = i + 1;
    if ~mod( i, 1000 ), fprintf( '.' ); end
    if ~mod( i, 10000 ), fprintf( ' ' ); end
    c = strsplit( tline );
    if length( c ) == xpLength
        q = q + 1;
        positionOrig( q, 1 ) = str2double( c{ 1 } );
        positionOrig( q, 2 ) = str2double( c{ 2 } );
        positionOrig( q, 3 ) = str2double( c{ 3 } );
        for qq = 4 : xpLength
            dataOrig( q, qq - 3 ) = str2double( c{ qq } );
        end
    end
    tline = fgetl( fid );
end

% dataOrig = load( [ './' subjId '/' area '.txt' ] );
% positionOrig = dataOrig( :, 1 : 3 ); dataOrig = dataOrig( :, 4 : end );

fprintf( '\nCleaning Data...' );

% clean zero voxels
cv = 0;
for v = 1 : size( dataOrig, 1 )
    if sum( dataOrig( v, : ) )
        cv = cv + 1;
        position( cv, : ) = positionOrig( v, : );
        data( cv, : ) = dataOrig( v, : );
    end
end

% z-score each voxel's response
m = mean( data, 2 ); s = std( data, [], 2 );
data = ( data - repmat( m, 1, size( data, 2 ) ) ) ./ repmat( s, 1, size( data, 2 ) );

fprintf( '\nSorting Data...' );

trsLost = 6; trLength = 1.500; trsPerRun = 514;
samples = nan( size( data, 1 ), numRuns, numCategories );

for r = 1 : numRuns
    startTRs = squeeze( round( timings.first( r, :, 1 ) / trLength - trsLost + hemoLag ) );
    endTRs = squeeze( ceil( ( timings.first( r, :, 1 ) + timings.first( r, :, 2 ) ) / trLength - trsLost + hemoLag ) );
    
    runData = data( :, ( params.dimOrder( r ) - 1 ) * trsPerRun + 1 : params.dimOrder( r ) * trsPerRun );
    stimIdxRun = zeros( 1, trsPerRun );
    for c = 1 : numCategories
        stimIdx = zeros( 1, trsPerRun );
        stimIdx( startTRs( c ) : endTRs( c ) ) = 1;
        stimIdxRun( startTRs( c ) : endTRs( c ) ) = 1;
        samples( :, r, c ) = mean( runData( :, stimIdx ~= 0 ), 2 );
    end
    
    if figuresOn, figure; plot( mean( runData, 1 ) ); hold on; plot( stimIdxRun * 0.5, 'r' ); end
end

fprintf( '\nSaving Data...' );

save( outputFile, 'samples', 'position' );

fprintf( '\n' );
